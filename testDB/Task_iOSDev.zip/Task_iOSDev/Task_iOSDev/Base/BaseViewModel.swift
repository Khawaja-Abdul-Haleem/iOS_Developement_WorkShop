//
//  BaseViewModel.swift
//  Task_iOSDev
//
//  Created by Khawaja Abdul Haleem on 25/10/2022.
//

import Foundation

class BaseViewModel {
    
    let mDataManager:DataManager = DataManager()
   
    
    
}

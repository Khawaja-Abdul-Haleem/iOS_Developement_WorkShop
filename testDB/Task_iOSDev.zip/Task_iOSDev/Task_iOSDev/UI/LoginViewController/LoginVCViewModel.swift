//
//  LoginVCViewModel.swift
//  Task_iOSDev
//
//  Created by Khawaja Abdul Haleem on 24/10/2022.
//

import Foundation

class LoginVCViewModel {
    
    var userModel = UserModel(email: "", password: "")
}

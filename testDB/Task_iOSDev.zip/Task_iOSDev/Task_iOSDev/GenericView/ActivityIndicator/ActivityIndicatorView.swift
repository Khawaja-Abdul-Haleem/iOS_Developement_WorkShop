//
//  ActivityIndicatorView.swift
//  Toothdolist
//
//  Created by Hammad Hassan on 20/01/2021.
//  Copyright © 2021 TechSwivel. All rights reserved.
//

import UIKit

class ActivityIndicatorView: UIView {

    override class func awakeFromNib() {
        super.awakeFromNib()
        
    }

}
